# BOOMER
Open source Quadruped Robot Pet
Developed by: Akhil P Jacob
HLRobotics & Software Automations

Language:Micro Python

Current Features:
*Emotion Based Facial Expression (Happy/Sad)
*Emotion Based Sound
*Movement Forward
*Inimidate
*BT Communication System
*IR Based obstacle detection
*Boomer App

Features under R&D:
*Vision
*Gesture Based Control
*Other Motion
*Analysis to be done
*Inverse kinematics and rebuild code
*All Emotion (Other missing Emoions)
*Games
*ROS protocols (ROS Serial with micropython if available)