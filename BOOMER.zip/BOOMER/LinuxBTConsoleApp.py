from HL_Engine import HLEngine_communications
while True:
    print("[BOOMER ALLIGNMENT SETUP INITIALIZATION CONSOLE ]")
    HLEngine_communications.botAccess("FC:A8:9A:00:34:F0")